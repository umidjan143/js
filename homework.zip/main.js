// //1
// function check(a) {
    


// if( a > 0 ) {
//         console.log("musbat");
//      }else{
//         console.log("manfiy");
//      }

// } check(0);



// //2

//  function check(a) {
    
 

//  if ( a%2==0 )
//  {
//     console.log("juft");
//  }else{
//     console.log("toq");
//  }
//  }

//  check(3);





//  //3

//  function check(a) {
    
 

//     if ( a%2!=0 )
//     {
//        console.log("toq");
//     }else{
//        console.log("juft");
//     }
//     }
   
//     check(3);




//     //4

//     function check(a,b) {
        
    
//  if( a > 0 && b>0 ) {
//          console.log("musbat");
//       }else{
//          console.log("manfiy");
//       }

//     }  check(3,7);


//5

// function check(a,b,c) {
    


// if (a>b && b>c)
// {console.log(true);}
// else{console.log(false);}
// } check(6,8,4);




// //6
// function check(a,b,c) {
    



//     if (a>b && b>c || c>b && b > a)
//     {console.log(true);}
//     else{console.log(false);}
    




//     } check(6,5,4);



//7

// function check(a,b) {
    


//     if( a%2 != 0 && b%2 != 0) {
//         console.log("toq");
//     }else {console.log("toqEmas");}
    




//     } check(6,5);




//8


// function check(a,b,c,d) {
 
// if (a>0 && b>0 && c>0 && d>0 ) {
//     console.log(true);
//     } else {console.log(false) ;
    
//     }
    
// }check(6,5,4,3);



//9

// function check(a,b,c) {
    

    
//     if (a>0 && b> 0 && c<0 || b>0 && c> 0 && a<0 || a>0 && c> 0 && b<0) {
//     console.log(true);
//     } else {console.log(false);}
    

// }  check(4,5,0);





//10  



// function check(a) {

    

// switch (a) {
//     case 1 :
//         console.log("monday");
//         break ;

//     case 2 :
//         console.log("tuesday");
//         break ;

//     case 3 :
//         console.log("wednesday");
//         break ;

//     case 4 :
//         console.log("thursday");
//         break ;

//     case 5 :
//         console.log("friday");
//         break ;

//     case 6 :
//         console.log("saturday");
//         break ;

//         case 7 :
//         console.log("sunday");
//         break ;
//   default:
//     console.log("mavjudEmas");


// }

    
// }

// check(5) ;






//11


// function check(a) {
    


    
// switch (a) {
//     case 99:
//       console.log("UZMOBILE");
//       break;
  
//     case 90:
//       console.log("BEELINE");
//       break;
  
//     case 93:
//       console.log("UCELL");
//       break;
  
//     case 91:
//       console.log("BEELINE");
//       break;
  
//     case 94:
//       console.log("UCELL");
//       break;
  
//     case 95:
//       console.log("UMS");
//       break;
  
//     case 88:
//       console.log("UMS");
//       break;
  
//     case 33:
//       console.log("HUMANS");
//       break;
  
//     default:
//       console.log("mavjudEmas");
    
//   }
// }

// check(33);



//12

// function check(a) {

    
// if (a>0) { console.log(a+1);

// } else { console.log(a-1);

// }
    
// } check(8);



//13

// function check(a) {
 
//     if (a>0) { console.log(a+3);
//     } else { console.log(a-2);
//     }
     
//     } check(8);




//14


// function check(a,b) {
//     if (a>b) { console.log(a);
    
//     } else { console.log(b);
    
//     }
    
// } check(5,9);



//15


// function check(a,b,c) {

    
// if (a>b) { if (a>c) {console.log(a);

// } else {
// console.log(c);
// }

// } else { if (b>c) { console.log(b);

// } else {console.log(c);

// }

// }
    
// } check(5,12,7);



//16


// function check(a,b,c) {
    

    
// if (a<b) { if (a<c) {console.log(a);

// } else {
// console.log(c);
// }

// } else { if (b<c) { console.log(b);

// } else {console.log(c);

// }

// }

// } check(5,12,7);





//17



// function check(a) {
    


// switch (a) {
//     case "m" : console.log('erkak');

//         break;

// case "f" : console.log('ayol');

// break;
//     default: console.log("mavjud_emas");
//         break;
// }
// }  check("m");



//18

// function check(a) {
    

// switch (a) {
//     case 5 : console.log("500.000 so'm");

//         break;
// case 4 : console.log("400.000 so'm");
// break;

// case 3 : console.log("300.000 so'm");
// break;

//          }
//         }
//          check(5);



//19

// function check(a) {
    
// if( a > 0 ) {
//     if (a%2==0) {console.log("juftMusbat");

//     } else { console.log("toqMusbat");

//     }
//  }else{
//     if (a%2==0) { console.log("juftManfiy");

//     } else {
//         console.log("toqManfiy");
//     }
//  }

    
// }
// check(-6);


// //20

// function check(year) 

// {

// var age=2023-year ;

// console.log(age);




    
// } check(2021);




//21


// function check(A,B,C) {

    
// if (A>=B && B>=C) { console.log("true");

// } else { console.log("false");

// }
    
// }

// check(5,5,7)




//22



// function check(a,b) {

    
// if (a%2!=0 && b%2==0 || a%2==0 && b%2!=0  )  { console.log("true");

// } else {console.log("false");

// }
    
// }
// check(5,5)




//23


// function check(a,b,c) {

    
// if (a>0 && b>0 && c>0) { console.log("true");

// } else {console.log("false");

// }

    
// } check(5,6,0);


//24


// function check(a,b,c) {
    
// if (a>0 && b<0 && c<0 || b>0 && a<0 && c<0 || c>0 && b<0 && a<0)  {console.log("true");

// } else {console.log("false");

// }

// }  check(5,-8,-2);


//25

//-


//26

//-




//27


// function check(laptop) {
    

//     switch (laptop) {
//         case "hp" :
//             console.log("$500");
//             break ;
    
//         case "victus" :
//             console.log("$600");
//             break ;
    
//         case 'lenovo' :
//             console.log("$500");
//             break ;
    
//         case 'acer' :
//             console.log("$400");
//             break ;
//     case 'asus' :
//             console.log("$500");
//             break ;
    
//               default: console.log("mavjud_emas");
//             break;
    
//     }

// }check("asus");





//28

//-